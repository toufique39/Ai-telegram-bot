def format_reply(user_name: str, reply: str) -> str:
    return reply
